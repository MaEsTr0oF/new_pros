export const serviceTranslations: Record<string, string> = {
  // Секс
  'classic': 'Классический',
  'anal': 'Анальный',
  'lesbian': 'Лесбийский',
  'group_mmf': 'Групповой (МЖМ)',
  'group_ffm': 'Групповой (ЖМЖ)',
  'with_toys': 'С игрушками',
  'in_car': 'В авто',

  // Ласки клиенту
  'blowjob_with_condom': 'Минет в презервативе',
  'blowjob_without_condom': 'Минет без презерватива',
  'deep_blowjob': 'Глубокий минет',
  'car_blowjob': 'Минет в авто',
  'anilingus_to_client': 'Анилингус',
  'fisting_to_client': 'Фистинг',
  'kisses': 'Поцелуи',

  // BDSM и фетиш
  'light_domination': 'Лёгкая доминация',
  'mistress': 'Госпожа',
  'flogging': 'Порка',
  'trampling': 'Трамплинг',
  'face_sitting': 'Фейсситтинг',
  'strapon': 'Страпон',
  'bondage': 'Бондаж',
  'slave': 'Рабыня',
  'role_play': 'Ролевые игры',
  'foot_fetish': 'Фут-фетиш',
  'golden_rain_out': 'Зол. дождь выдача',
  'golden_rain_in': 'Зол. дождь прием',
  'copro_out': 'Копро выдача',
  'copro_in': 'Копро прием',
  'enema': 'Клизма',

  // Эротический массаж
  'relaxing': 'Расслабляющий',
  'professional': 'Профессиональный',
  'body_massage': 'Массаж телом',
  'lingam_massage': 'Массаж лингама',
  'four_hands': 'В четыре руки',
  'urological': 'Урологический',

  // Шоу
  'strip_pro': 'Стриптиз профи',
  'strip_amateur': 'Стриптиз любительский',
  'belly_dance': 'Танец живота',
  'twerk': 'Тверк',
  'lesbian_show': 'Лесби-шоу',

  // Виртуальные услуги
  'sex_chat': 'Секс чат',
  'phone_sex': 'Секс по телефону',
  'video_sex': 'Секс по видео',
  'photo_video': 'Отправка фото/видео',

  // Могу позвать
  'invite_girlfriend': 'Подругу',
  'invite_friend': 'Друга',

  // Дополнительно
  'escort': 'Эскорт',
  'photoshoot': 'Фотосъёмка',
  'skirt': 'Сквирт',
}; 