import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Button,
  Tooltip,
  CircularProgress,
  Box,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import AdminLayout from '../../components/admin/AdminLayout';
import { apiClient } from '../../api-wrapper';
import ProfileOrderButtons from '../../components/admin/ProfileOrderButtons';

const ProfilesPage: React.FC = () => {
  const [profiles, setProfiles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [profileToDelete, setProfileToDelete] = useState<number | null>(null);

  useEffect(() => {
    fetchProfiles();
  }, []);

  const fetchProfiles = async () => {
    try {
      setLoading(true);
      const response = await apiClient.get('/admin/profiles');
      setProfiles(response.data);
      setError('');
    } catch (err) {
      console.error('Ошибка при загрузке профилей:', err);
      setError('Не удалось загрузить данные. Пожалуйста, попробуйте позже.');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (id: number) => {
    window.location.href = `/admin/profiles/edit/${id}`;
  };

  const handleOpenDeleteDialog = (id: number) => {
    setProfileToDelete(id);
    setDeleteDialogOpen(true);
  };

  const handleCloseDeleteDialog = () => {
    setDeleteDialogOpen(false);
    setProfileToDelete(null);
  };

  const handleDelete = async () => {
    if (profileToDelete) {
      try {
        await apiClient.delete(`/admin/profiles/${profileToDelete}`);
        setDeleteDialogOpen(false);
        setProfileToDelete(null);
        fetchProfiles();
      } catch (err) {
        console.error('Ошибка при удалении профиля:', err);
        alert('Не удалось удалить профиль');
      }
    }
  };

  return (
    <AdminLayout>
      <Container>
        <Typography variant="h4" component="h1" gutterBottom>
          Управление анкетами
        </Typography>

        <Box sx={{ mb: 2, display: 'flex', justifyContent: 'flex-end' }}>
          <Button
            variant="contained"
            color="primary"
            onClick={() => window.location.href = '/admin/profiles/create'}
          >
            Добавить новую анкету
          </Button>
        </Box>

        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
            <CircularProgress />
          </Box>
        ) : error ? (
          <Typography color="error">{error}</Typography>
        ) : (
          <Paper>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>ID</TableCell>
                    <TableCell>Имя</TableCell>
                    <TableCell>Возраст</TableCell>
                    <TableCell>Город</TableCell>
                    <TableCell>Цена</TableCell>
                    <TableCell>Статус</TableCell>
                    <TableCell>Действия</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {profiles.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} align="center">
                        Анкеты не найдены
                      </TableCell>
                    </TableRow>
                  ) : (
                    profiles.map((profile) => (
                      <TableRow key={profile.id}>
                        <TableCell>{profile.id}</TableCell>
                        <TableCell>{profile.name}</TableCell>
                        <TableCell>{profile.age}</TableCell>
                        <TableCell>{profile.city?.name || 'Не указан'}</TableCell>
                        <TableCell>{profile.price1Hour} ₽/час</TableCell>
                        <TableCell>
                          <Tooltip title={profile.isActive ? 'Активен' : 'Неактивен'}>
                            <IconButton size="small" color={profile.isActive ? 'success' : 'error'}>
                              {profile.isActive ? <CheckCircleIcon /> : <CancelIcon />}
                            </IconButton>
                          </Tooltip>
                          {profile && <ProfileOrderButtons profileId={profile.id} />}
                        </TableCell>
                        <TableCell>
                          <IconButton
                            onClick={() => handleEdit(profile.id)}
                            size="small"
                            color="primary"
                          >
                            <EditIcon />
                          </IconButton>
                          <IconButton
                            onClick={() => handleOpenDeleteDialog(profile.id)}
                            size="small"
                            color="error"
                          >
                            <DeleteIcon />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        )}

        <Dialog
          open={deleteDialogOpen}
          onClose={handleCloseDeleteDialog}
        >
          <DialogTitle>Удаление анкеты</DialogTitle>
          <DialogContent>
            <DialogContentText>
              Вы уверены, что хотите удалить эту анкету? Это действие нельзя будет отменить.
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseDeleteDialog} color="primary">
              Отмена
            </Button>
            <Button onClick={handleDelete} color="error" autoFocus>
              Удалить
            </Button>
          </DialogActions>
        </Dialog>
      </Container>
    </AdminLayout>
  );
};

export default ProfilesPage;
