import React, { useState, useEffect } from 'react';
import { Container, Typography, Grid, Card, CardContent, CardActions, IconButton,
         Button, CircularProgress, Box, Paper, Divider } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import AdminLayout from '../../components/admin/AdminLayout';
import { apiClient } from '../../api-wrapper';
import ProfileOrderButtons from '../../components/admin/ProfileOrderButtons';

const AdminDashboard: React.FC = () => {
  const [profiles, setProfiles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchProfiles();
  }, []);

  const fetchProfiles = async () => {
    try {
      setLoading(true);
      const response = await apiClient.get('/admin/profiles');
      setProfiles(response.data);
      setError('');
    } catch (err) {
      console.error('Ошибка при загрузке профилей:', err);
      setError('Не удалось загрузить данные. Пожалуйста, попробуйте позже.');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (id: number) => {
    window.location.href = `/admin/profiles/edit/${id}`;
  };

  const handleDelete = (id: number) => {
    if (window.confirm('Вы уверены, что хотите удалить эту анкету?')) {
      apiClient.delete(`/admin/profiles/${id}`)
        .then(() => {
          fetchProfiles();
        })
        .catch((err) => {
          console.error('Ошибка при удалении:', err);
          alert('Не удалось удалить анкету');
        });
    }
  };

  return (
    <AdminLayout>
      <Container>
        <Typography variant="h4" component="h1" gutterBottom>
          Панель управления
        </Typography>

        <Paper sx={{ padding: 2, mb: 4 }}>
          <Typography variant="h5" gutterBottom>
            Недавние анкеты
          </Typography>
          <Divider sx={{ mb: 2 }} />

          {loading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
              <CircularProgress />
            </Box>
          ) : error ? (
            <Typography color="error">{error}</Typography>
          ) : (
            <>
              <Grid container spacing={3}>
                {profiles.slice(0, 6).map((profile) => (
                  <Grid item xs={12} sm={6} md={4} key={profile.id}>
                    <Card>
                      <CardContent>
                        <Typography variant="h6">{profile.name}</Typography>
                        <Typography color="textSecondary">{profile.age} лет</Typography>
                        <Typography variant="body2">
                          {profile.city?.name || 'Город не указан'}
                        </Typography>
                        <Typography variant="body2">
                          {profile.price1Hour} ₽/час
                        </Typography>
                        <Typography variant="body2">
                          Статус: {profile.isActive ? 'Активен' : 'Неактивен'}
                        </Typography>
                      </CardContent>
                      <CardActions>
                        <IconButton
                          onClick={() => handleEdit(profile.id)}
                          size="small"
                          color="primary"
                        >
                          <EditIcon />
                        </IconButton>

                        {profile && <ProfileOrderButtons profileId={profile.id} />}

                        <IconButton
                          onClick={() => handleDelete(profile.id)}
                          size="small"
                          color="error"
                        >
                          <DeleteIcon />
                        </IconButton>
                      </CardActions>
                    </Card>
                  </Grid>
                ))}
              </Grid>

              {profiles.length > 6 && (
                <Box sx={{ mt: 2, textAlign: 'right' }}>
                  <Button
                    variant="outlined"
                    onClick={() => window.location.href = '/admin/profiles'}
                  >
                    Показать все анкеты
                  </Button>
                </Box>
              )}

              {profiles.length === 0 && (
                <Typography align="center" sx={{ py: 3 }}>
                  Анкеты не найдены
                </Typography>
              )}
            </>
          )}
        </Paper>

        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
          <Button
            variant="contained"
            color="primary"
            onClick={() => window.location.href = '/admin/profiles/create'}
          >
            Добавить новую анкету
          </Button>
        </Box>
      </Container>
    </AdminLayout>
  );
};

export default AdminDashboard;
