import api from './api/index';

// Экспорт API клиента для обратной совместимости
export const apiClient = api;

// Экспорт основных методов API для работы с профилями
export const getProfiles = () => api.get('/admin/profiles');
export const createProfile = (data) => api.post('/admin/profiles', data);
export const updateProfile = (id, data) => api.put(`/admin/profiles/${id}`, data);
export const deleteProfile = (id) => api.delete(`/admin/profiles/${id}`);
export const moveUp = (id) => api.post(`/admin/profiles/${id}/move-up`);
export const moveDown = (id) => api.post(`/admin/profiles/${id}/move-down`);

// Экспорт методов для работы с городами
export const getCities = () => api.get('/cities');
export const createCity = (data) => api.post('/admin/cities', data);
export const updateCity = (id, data) => api.put(`/admin/cities/${id}`, data);
export const deleteCity = (id) => api.delete(`/admin/cities/${id}`);

// Экспорт API по умолчанию
export default api;
