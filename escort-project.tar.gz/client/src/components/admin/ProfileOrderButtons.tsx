import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import api from '../../api/index';

interface ProfileOrderButtonsProps {
  profileId: number;
}

/**
 * Компонент с кнопками для изменения порядка отображения профилей
 */
const ProfileOrderButtons: React.FC<ProfileOrderButtonsProps> = ({ profileId }) => {
  const handleMoveUp = async () => {
    try {
      await api.post(`/admin/profiles/${profileId}/move-up`);
      // После успешного запроса можно обновить список
      window.location.reload();
    } catch (error) {
      console.error('Ошибка при изменении порядка профиля:', error);
      alert('Не удалось переместить профиль вверх');
    }
  };

  const handleMoveDown = async () => {
    try {
      await api.post(`/admin/profiles/${profileId}/move-down`);
      // После успешного запроса можно обновить список
      window.location.reload();
    } catch (error) {
      console.error('Ошибка при изменении порядка профиля:', error);
      alert('Не удалось переместить профиль вниз');
    }
  };

  return (
    <>
      <Tooltip title="Переместить вверх">
        <IconButton size="small" color="primary" onClick={handleMoveUp}>
          <ArrowUpwardIcon fontSize="small" />
        </IconButton>
      </Tooltip>
      <Tooltip title="Переместить вниз">
        <IconButton size="small" color="primary" onClick={handleMoveDown}>
          <ArrowDownwardIcon fontSize="small" />
        </IconButton>
      </Tooltip>
    </>
  );
};

export default ProfileOrderButtons;
