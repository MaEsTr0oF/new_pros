#!/bin/bash
set -e

echo "🔍 Проверяю маршруты API для перемещения профилей..."
SERVER_INDEX="/root/escort-project/server/src/index.ts"
if [ -f "$SERVER_INDEX" ]; then
  # Создаем резервную копию
  cp "$SERVER_INDEX" "${SERVER_INDEX}.bak_routes"
  
  # Добавляем маршруты для перемещения профилей напрямую
  cat > /tmp/routes_to_add.txt << 'END'
// Маршруты для управления порядком профилей
app.patch('/api/admin/profiles/:id/moveUp', profileController.moveProfileUp);
app.patch('/api/admin/profiles/:id/moveDown', profileController.moveProfileDown);
END

  # Ищем подходящее место и добавляем маршруты
  TEMP_FILE="/tmp/server_index_updated.ts"
  cat "$SERVER_INDEX" | awk '
  /app.patch.*\/api\/admin\/profiles\/:id\/verify/ {
    print $0;
    print "";
    system("cat /tmp/routes_to_add.txt");
    next;
  }
  { print $0 }
  ' > "$TEMP_FILE"
  
  # Копируем обновленный файл
  cp "$TEMP_FILE" "$SERVER_INDEX"
  echo "✅ Маршруты для перемещения профилей добавлены"
else
  echo "❌ Файл index.ts не найден!"
fi

echo "🚀 Перезапускаем серверную часть..."
cd /root/escort-project
docker-compose restart server

echo "✅ Маршруты API для управления порядком настроены!"
echo "🌐 Проверьте кнопки на странице: https://eskortvsegorodarfreal.site/admin/dashboard"
